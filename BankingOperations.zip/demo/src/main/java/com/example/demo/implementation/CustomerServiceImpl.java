package com.example.demo.implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Customer getCustomerById(Integer customerId) throws Exception {
		Optional<Customer> customer = customerRepository.findById(customerId);
		if(!customer.isPresent())
			throw new ResourceNotFoundException("Customer by ID "+ customerId+ " not found");
		return customer.get();
	}

	@Override
	public Customer save(Customer customer) throws Exception {
		Customer newcustomer = customerRepository.save(customer);
		return newcustomer;
	}

	@Override
	public void deleteCustomer(Integer customerId) throws Exception {
		Optional<Customer> customer = customerRepository.findById(customerId);
		if(!customer.isPresent())
			throw new ResourceNotFoundException("Customer by ID "+ customerId+ " not found");
		 customerRepository.deleteById(customerId);
	}

	@Override
	public Customer update(Customer customer) throws Exception {
		Optional<Customer> existingCustomer = customerRepository.findById(customer.getCustomerId());
		if(!existingCustomer.isPresent())
			throw new ResourceNotFoundException("Customer by ID "+ customer.getCustomerId()+ " not found");
		return customerRepository.save(customer);
	}

}

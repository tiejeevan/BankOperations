package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Account;
import com.example.demo.model.Customer;
import com.example.demo.service.AccountService;
import com.example.demo.service.CustomerService;

@RestController
public class AccountController {
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private AccountService accountService;
	
	@PostMapping(value = "/account/{customerId}")
	@ResponseStatus(code = HttpStatus.CREATED)
	public Account save(@PathVariable Integer customerId,@RequestBody Account  account) throws Exception {
		Customer customer =  customerService.getCustomerById(customerId);
		account.setCustomer(customer);
		return accountService.save(account);
		

	 }
	
	@GetMapping(value = "/account/{customerId}") 
	 public List<Account> all (@PathVariable Integer customerId) throws Exception{ 
		customerService.getCustomerById(customerId);
        return accountService.findByCustomerCustomerId(customerId);
	 } 
	
	@DeleteMapping(value = "/account/{customerId}/accounts/{accountId}")
	public void deleteAccount(@PathVariable Integer customerId,@PathVariable Integer accountId) throws Exception{

		customerService.getCustomerById(customerId);	
		accountService.delete( accountId);

	}
	
	@PutMapping(value = "/account/{customerId}/accounts/{accountId}")
	public void updateAccount(@PathVariable Integer customerId,@PathVariable Integer accountId,@RequestBody Account newAccount) throws Exception{

		Customer customer = customerService.getCustomerById(customerId);
		newAccount.setCustomer(customer);
		accountService.update(newAccount);

		
	}

}

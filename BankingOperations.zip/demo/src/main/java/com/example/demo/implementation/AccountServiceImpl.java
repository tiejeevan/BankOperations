package com.example.demo.implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.model.Account;
import com.example.demo.repository.AccountRepository;
import com.example.demo.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	private AccountRepository accountRepository;

	@Override
	public Account save(Account account) throws Exception {
		Account newAccount = accountRepository.save(account);
		return newAccount;
	}

	@Override
	public void delete(Integer accountId) throws Exception {
		Optional<Account> account = accountRepository.findById(accountId);
		if(!account.isPresent())
			throw new ResourceNotFoundException("Account by ID "+ accountId+ " not found");
		accountRepository.deleteById(accountId);
	}

	@Override
	public Account update(Account newAccount) throws Exception {
		Optional<Account> account = accountRepository.findById(newAccount.getAccountNumber());
		if(!account.isPresent())
			throw new ResourceNotFoundException("Account by Account Number  "+ newAccount.getAccountNumber()+ " not found");
		return accountRepository.save(newAccount);
	}

	@Override
	public List<Account> findByCustomerCustomerId(Integer customerId) throws Exception {
		return accountRepository.findByCustomerCustomerId(customerId);
	}

}

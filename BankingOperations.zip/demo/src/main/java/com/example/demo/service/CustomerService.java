package com.example.demo.service;

import org.springframework.http.ResponseEntity;

import com.example.demo.model.Account;
import com.example.demo.model.Customer;

public interface CustomerService {

	Customer getCustomerById(Integer customerId) throws Exception;

	Customer save(Customer customer) throws Exception;

	void deleteCustomer(Integer customerId)  throws Exception;

	Customer update(Customer customer) throws Exception;

}

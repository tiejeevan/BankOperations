package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Account;

public interface AccountService {

	Account save(Account account) throws Exception;

	void delete(Integer accountId) throws Exception;

	Account update(Account newAccount) throws Exception;

	List<Account> findByCustomerCustomerId(Integer customerId) throws Exception;

}
